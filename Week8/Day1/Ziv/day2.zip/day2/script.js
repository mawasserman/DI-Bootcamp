/** Review on function
 * function declaration
 * function expresion
 * hoisting
 * self invoke function
 */

// ES6
// nameOfFunction();
// function nameOfFunction() {
//   //.....
//   console.log("function nameOfFunction()");
// }
// nameOfFunction();

// // sum()
// let sum = function () {
//   //...
//   return "function sum";
// };
// console.log(sum());

// let getFullNAme = (param1, param2) => 1;

// console.log(getFullNAme)

// self invoke function

// (function (a, b) {
//   //....
//   console.log("main", a, b);
// })("go", "no go");

// ((a, b) => {
//   //....
//   console.log("main", a, b);
// })("go", "no go");

// nested function

// function nested() {
//   let b = "outer variable";
//   function innerNested() {
//     console.log(b);
//     let a = "hello";
//   }
//   // console.log(a);
//   return innerNested
// }

// let ret = nested()
// // console.log(ret);
// ret()

function sum(a) {
  return (b) => {
    return a * b;
  };
}
// clousers
// let sum1 = sum(5);
// let sum2 = sum(10);
// console.log(sum1);
// console.log(sum2);

// console.log(sum1(5));
// console.log(sum2(6));

// currying
// let sum3 = (a) => (b) => {
// return a + b;
// };

// let sum4 = (a) => (b) => a + b;

// let result = sum4(3)(5)
// console.log(result);

// function currying(f) {
//   return function (a) {
//     return function (b) {
//       return f(a, b);
//     };
//   };
// }

// function sum(a, b) {
//   return a * b;
// }

// let currySum = currying(sum)
// let vat = 1.19
// console.log(currySum(vat)(2));
// console.log(currySum(vat)(20));

/**
 * Objects
 */

// let obj1 = {
//   age: 15,
// };
// let obj2 = new Object();

// obj1.name = "John";

// let last = 'lastname'
// obj1[last] = "Due";

// console.log(obj1);

// // console.log(obj1.age);
// // console.log(obj1['name']);

// let column1 = "aaaa";

// let user = {
//   [column1]: "John",
// };

// console.log(user);

// console.log(obj1);

// for(let x in obj1) {
//   console.log(x, obj1[x]);
// }

// Shorthand value property

// let name = "John";
// let age = 15;
// let username = "jjjj";

// let user = {
// name,
// age,
// username,
// };
// user.aaa = "bbb";
// user["ggg"] = "hhh";
// console.log(user);

/**
 * By Value / By Reference
 */
// let a = 7;
// let b = a;

// console.log(a, b);
// b = 8;
// console.log(a, b);

// const arr1 = [1, 2, 3];

// const arr3 = [].concat(arr1);
// const arr2 = [...arr1];

// arr2[1] = 5;
// console.log("arr1=>", arr1);
// console.log("arr2=>", arr2);

// let obj1 = {
//   a: 1,
//   b: 2,
//   c: 3,
// };

// let obj3 = Object.assign({}, obj1);
// let obj2 = { ...obj1 };

// obj2.b = 5;

// console.log("obj1=>", obj1);
// console.log("obj2=>", obj2);

let obj1 = {
  name: "John",
  last: "Due",
  address: {
    street: "Bezalel",
    num: 8,
    city: "ramat gan",
  },
};

let obj2 = { ...obj1 };
obj2.address = { ...obj1.address };
// obj2.address = obj2address

obj2.name = "Marry";
obj2.last = "Anne";

obj2.address.city = "New York";

console.log(obj1);
console.log(obj2);

// deep cloning
