const gameInfo = [
  {
    username: "john",
    team: "red",
    score: 5,
    items: ["ball", "book", "pen"],
  },
  {
    username: "becky",
    team: "blue",
    score: 10,
    items: ["tape", "backpack", "pen"],
  },
  {
    username: "susy",
    team: "red",
    score: 55,
    items: ["ball", "eraser", "pen"],
  },
  {
    username: "tyson",
    team: "green",
    score: 1,
    items: ["book", "pen"],
  },
];

let arr1 = [];
gameInfo.forEach((item) => {
  arr1.push(item.username + "!");
});
console.log(arr1);

let arr2 = [];
gameInfo.forEach((item) => {
  // item.score > 5 ? arr2.push(item.username) : null;
  if (item.score > 5) arr2.push(item.username);
});
console.log(arr2);

let score = 0;
gameInfo.forEach((item) => {
  score += item.score;
});
console.log(score);
