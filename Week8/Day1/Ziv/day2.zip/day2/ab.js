/*
You are tasked with writing a function `solution` that takes a string `S` as input. 
The string consists of 'a' and/or 'b' characters. 
The function should return `true` if all occurrences 
of the letter 'a' appear before all occurrences of the letter 'b' in the string `S`. 
If either 'b' does not occur in `S` or 'a' does not occur in `S`, 
the function should also return `true`. 
Otherwise, it should return `false`.


aabb - true
bbaa - flase
aaa - true
bbb - true
ababa - flase
*/

// let retA = 'bb'.indexOf('a');
// console.log(retA);

// function solution(S) {
//   let lastA_index = S.lastIndexOf("a");
//   let firstB_index = S.indexOf("b");
//   if (firstB_index === -1 || lastA_index === -1 || lastA_index < firstB_index) {
//     return true;
//   }
//   return false;
// }

// function solution(S) {
//   let lastIndexOfA = S.lastIndexOf('a');
//   let firstIndexOfB = S.indexOf("b");

//   for (let i = 0; i < S.length; i++) {
//     if (S[i] === "a") {
//       lastIndexOfA = i;
//     } else if (S[i] === "b" && lastIndexOfA > firstIndexOfB) {
//       return false;
//     }
//   }

//   return true;
// }

function solution(S) {
  let a = S.indexOf('a');
  let b = S.indexOf('b');
  if (a === -1 || b === -1) {
      return true;
  }
  if (a < b) {
      return true;
  } else {
      return false;
  }
}

// console.log(solution('aabb'));
// console.log(solution('bbaa'));
// console.log(solution('aaa'));
// console.log(solution('bbb'));
// console.log(solution('ababa'));

const testCases = [
  { input: "aaabbb", output: true },
  { input: "ba", output: false },
  { input: "aaa", output: true },
  { input: "b", output: true },
  { input: "a", output: true },
  { input: "abba", output: false },
  { input: "bbba", output: false },
  { input: "aabb", output: true },
  { input: "aababababababb", output: false },
  { input: "ab", output: true },
];

for (let i = 0; i < testCases.length; i++) {
  const input = testCases[i].input;
  const output = testCases[i].output;
  const result = solution(input);

  console.log(
    `Input: ${input}, Output: ${result}, Expected output: ${output}, Result: ${
      result === output ? "OK" : "NOT OK"
    }`
  );
}
